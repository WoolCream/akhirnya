const listsay = () => { 
	return `
	
	-fajargay
	-agunggay
	-orang
	-Prisonschool
    -masougakuenhxh
     -valxlove`
            }
exports.listsay = listsay